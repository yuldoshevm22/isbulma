<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
$conn = new mysqli("localhost", "kullanici_adi", "sifre", "veritabani_adi");
if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE email='$email'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password'])) {
        $_SESSION['user'] = $row['fullname'];
        echo "Giriş başarılı! Hoşgeldiniz, " . $row['fullname'];
        // Yönlendirme için: header("Location: anasayfa.html");
    } else {
        echo "Şifre yanlış!";
    }
} else {
    echo "Kullanıcı bulunamadı!";
}
$conn->close();
?>