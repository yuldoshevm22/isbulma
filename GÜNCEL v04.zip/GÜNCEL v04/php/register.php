<?php
<?php
// Veritabanı bağlantısı
$conn = new mysqli("localhost", "kullanici_adi", "sifre", "veritabani_adi");
if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

$fullname = $_POST['fullname'];
$email = $_POST['email'];
$password = $_POST['password'];

// Şifreyi hashleyin (güvenlik için)
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Email zaten kayıtlı mı kontrol et
$sql = "SELECT * FROM users WHERE email='$email'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo "Bu email zaten kayıtlı!";
} else {
    $sql = "INSERT INTO users (fullname, email, password) VALUES ('$fullname', '$email', '$hashed_password')";
    if ($conn->query($sql) === TRUE) {
        echo "Kayıt başarılı! <a href='../login.html'>Giriş yap</a>";
    } else {
        echo "Hata: " . $conn->error;
    }
}
$conn->close();
?>